package edu.wccnet.cooconnor.DIDemo;

import org.springframework.stereotype.Component;

@Component
public class Grants implements FinaidService {

	public String getFinaidType() {
		// TODO Auto-generated method stub
		return "Grants";
	}

}
