package edu.wccnet.cooconnor.DIDemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("edu.wccnet.cooconnor.DIDemo")
public class DIDemoJavaConfig {

	
	
	
	
}
