package edu.wccnet.cooconnor.DIDemo;

public interface FinaidService {
	String getFinaidType();
}
