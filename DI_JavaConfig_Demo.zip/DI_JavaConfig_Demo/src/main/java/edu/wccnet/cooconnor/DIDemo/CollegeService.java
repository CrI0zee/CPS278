package edu.wccnet.cooconnor.DIDemo;

public interface CollegeService {
	String getService(String collegeName);
}
