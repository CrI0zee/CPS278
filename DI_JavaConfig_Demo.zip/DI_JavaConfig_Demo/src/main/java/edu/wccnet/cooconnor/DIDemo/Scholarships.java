package edu.wccnet.cooconnor.DIDemo;

public class Scholarships implements FinaidService {

	public String getFinaidType() {
		// TODO Auto-generated method stub
		return "Scholarships";
	}

}
